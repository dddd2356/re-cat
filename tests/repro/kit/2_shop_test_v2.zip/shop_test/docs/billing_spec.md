# 청구 명세 (2022)

## 1단계: 금액 계산
`InvoiceService.issue`가 `InvoiceService.total`을 호출한다.

## 2단계: 세금
`InvoiceService.total` → `calc_tax`

## 3단계: 메일 발송
`InvoiceService.issue` → `send_invoice`
발송 전에 PDF를 만든다: `InvoiceService.issue` → `PdfRenderer.render`
