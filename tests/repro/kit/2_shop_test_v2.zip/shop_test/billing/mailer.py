def send_invoice(order_id, total):
    body = _render(order_id, total)
    return _deliver(body)


def _render(order_id, total):
    return f"invoice {order_id}: {total}"


def _deliver(body):
    return True
