RATE = 0.1


def calc_tax(amount):
    return round(amount * RATE)
