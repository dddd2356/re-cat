from .tax import calc_tax
from .mailer import send_invoice


class InvoiceService:
    """청구서 발행: 금액 계산 → 세금 → 메일 발송."""

    def issue(self, order_id, amount):
        total = self.total(amount)
        send_invoice(order_id, total)
        return total

    def total(self, amount):
        return amount + calc_tax(amount)

    def void(self, order_id):
        """청구서 취소 (동적 호출)."""
        handler = getattr(self, "on_void")
        return handler(order_id)
